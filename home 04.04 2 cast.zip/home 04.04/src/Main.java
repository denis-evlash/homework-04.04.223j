import java.util.Scanner;

public class Main {
    //Проект 2. Используйте for.
    //Необходимо суммировать все нечётные целые числа в диапазоне,введённом пользователем.
    // Пользователь указывает нижнюю и верхнюю границу диапазона.
    public static void main(String[] args) {

        Scanner scr = new Scanner(System.in);
        System.out.println("Введите нижнюю границу диапозона (число) : ");
        int number = scr.nextInt();
        System.out.println("Введите верхнюю границу диапозона (число) : ");
        int number1 = scr.nextInt();
        int sum = 0;
        for (int i = number; i <= number1 ; i++) {
            if (i % 2==1){
                sum = sum +i;
            }
            
        }
        System.out.println("сумма нечетных чисел в диапозоне от " + number +" "+ "до"+ " " +  number1 + " " +"=" +" "+sum);


    }
}