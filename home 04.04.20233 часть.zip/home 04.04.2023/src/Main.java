import java.time.Month;
import java.util.Scanner;

public class Main {
    //Используйте foreach.
    //Дан Enum месяцев.
    // Пользователь вводит имя текущего месяца в консоль.
    // Программа должна вывести все месяцы, кроме того, что ввёл пользователь.
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        System.out.println("Введите название текущего месяца по английски: ");
        String monthName = scn.nextLine().toUpperCase();
        Month montch1 = Month.valueOf(monthName);
        System.out.println("Остальные месяцы ");
        for (Month month : Month.values()) {
            if (month != montch1) {
                System.out.print(month.name() + " ");
            }
        }
    }
}